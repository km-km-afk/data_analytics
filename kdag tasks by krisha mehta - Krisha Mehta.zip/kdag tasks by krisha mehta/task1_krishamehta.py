
import pygame
import random

pygame.init()

screen = pygame.display.set_mode((800, 800)) 
pygame.display.set_caption("Langton’s Ants")
icon = pygame.image.load('ant.png')
pygame.display.set_icon(icon)
FPS = 60  # Lower FPS so that we can observe the movement of 2 ants properly
grid_size = 100
cell_size = 8  
decaysteps = 5  


White = (255, 255, 255)
Black = (0, 0, 0)
Ant1_Color = (255, 30, 100)  # Color for Ant 1 (A)(shade of pink)
Ant2_Color = (100, 30, 255)  # Color for Ant 2 (B)(shade of purple)
Grid_Line_Color = (200, 200, 200)  

#Right, Down, Left, Up
DIRECTIONS = [(1, 0), (0, 1), (-1, 0), (0, -1)]  # Each ordered pair (dx, dy) directly represents the change in the x and y coordinates when the ant moves in that direction thus simplifies ant motion in the code
clock = pygame.time.Clock() 

grid = [[0 for _ in range(grid_size)] for _ in range(grid_size)]  
pheromones = [[None for _ in range(grid_size)] for _ in range(grid_size)]  # None, Ant 1, or Ant 2 #initially creates a matrix with each element as none
pheromone_timers = {}  # a dictionary that tracks decay of pheromones basically the key is the coordinate and the value is the decaysteps

class Ant:
    def __init__(self, x, y, color, pheromone_type):
        self.x = x % grid_size  # it ensures that the ant's initial x-coordinate is always within the bounds of the grid.
        self.y = y % grid_size  # it ensures that the ant's initial y-coordinate is always within the bounds of the grid.
        self.color = color
        self.pheromone_type = pheromone_type  # Ant 1 or Ant 2
        self.dir = random.randint(0, 3)  # Random initial direction
    
    def move(self):
        current_color = grid[self.y][self.x]
        current_pheromone = pheromones[self.y][self.x]  # if there is any harmone in that particular position
        
        # Pheromone influence (following the rules given in the question)
        if current_pheromone == self.pheromone_type:  # Self-pheromone
            if random.random() < 0.8:  # 80% chance to move straight
                pass  # Do not change direction
            else:
                self.turn(current_color)  # 20% chance to follow standard rule
        elif current_pheromone is not None:  # Cross-pheromone
            if random.random() < 0.2:  # 20% chance to move straight
                pass  
            else:
                self.turn(current_color)  # 80% chance to follow standard rule
        else:  # No pheromone
            self.turn(current_color)  # Follow standard rule
        
    
        grid[self.y][self.x] = 1 - grid[self.y][self.x]  # the fundamental rule of Langton's Ant: change the color of the cell you're standing on.If the current cell is white (0), this expression evaluates to 1 - 0 = 1 (black). If the current cell is black (1), this expression evaluates to 1 - 1 = 0 (white).
        pheromones[self.y][self.x] = self.pheromone_type  # assigning the ants pheromone in the given cell
        pheromone_timers[(self.x, self.y)] = decaysteps  # Reset decay timer
        
        dx, dy = DIRECTIONS[self.dir]
        self.x = (self.x + dx) % grid_size
        self.y = (self.y + dy) % grid_size
    
    def turn(self, current_color):
        if current_color == 0:  # White square: turn 90° clockwise
            self.dir = (self.dir + 1) % 4
        else:  # Black square: turn 90° counter-clockwise
            self.dir = (self.dir - 1) % 4

ant1 = Ant(50, 50, Ant1_Color, 'A')
ant2 = Ant(70, 70, Ant2_Color, 'B')

font = pygame.font.Font(None, 36)  

start_time = pygame.time.get_ticks()  # Get the starting time in milliseconds

running = True
while running:
    screen.fill(White)
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    
    ant1.move()
    ant2.move()
    
    # Decay pheromones
    to_remove = []
    for (x, y), timer in pheromone_timers.items():
        if timer > 0:
            pheromone_timers[(x, y)] -= 1
        else:
            pheromones[y][x] = None  # Remove pheromone
            to_remove.append((x, y))
    for coord in to_remove:
        del pheromone_timers[coord]
    
    # grid cells
    for y in range(grid_size):
        for x in range(grid_size):
            color = White if grid[y][x] == 0 else Black
            if pheromones[y][x] == 'A':  # when ant 1 releases pheromones
                color = Ant1_Color
            elif pheromones[y][x] == 'B':  # when ant 2 releases pheromones
                color = Ant2_Color
            pygame.draw.rect(screen, color, (x * cell_size, y * cell_size, cell_size, cell_size))  # to draw rectangular shapes on pygame surface
    
    for x in range(0, screen.get_width(), cell_size):
        pygame.draw.line(screen, Grid_Line_Color, (x, 0), (x, screen.get_height()))
    for y in range(0, screen.get_height(), cell_size):
        pygame.draw.line(screen, Grid_Line_Color, (0, y), (screen.get_width(), y))
    
    # Calculate elapsed time
    elapsed_time = (pygame.time.get_ticks() - start_time) // 1000 
    
    # timer
    text = font.render(f"Time: {elapsed_time} s", True, Black)  
    text_rect = text.get_rect(topleft=(10, 10)) 
    screen.blit(text, text_rect) 
    pygame.display.flip()
    clock.tick(FPS)

pygame.quit()